# The 30 Audited Sectors

Sector names only. **No findings, no audit detail, no figures are reproduced here.** The full sector extraction audits are published at https://marloweaudit.com/.

Each sector is measured against the four-axis MARLOWE Certification™ standard (Truth · Transparency · Moral Integrity · Direct Settlement). Uniform result across all thirty: 0 of 4.

1. Hyperscaler Grid Extraction
2. Health-Insurance Claims Extraction
3. Agentic-AI Authorization Extraction
4. Private-Credit Financial-Mirror Extraction
5. Credential / Student-Debt Extraction
6. Pharmacy-Benefit-Manager Extraction
7. Attention Extraction
8. Child-Welfare Algorithmic Extraction
9. Platform-Labor Extraction
10. Criminal-Justice Risk-Score Extraction
11. Housing-Algorithm Extraction
12. Insurance Price-Optimization Extraction
13. Data-Broker Extraction
14. Equipment-Lockout / Right-to-Repair Extraction
15. Academic-Publishing Extraction
16. Digital-Ownership / DRM Extraction
17. Genomic-Data Extraction
18. Water-Privatization Extraction
19. Subscription Lock-In Extraction
20. Digital-Identity Extraction
21. Telecom-Throttling Extraction
22. Tolling-Congestion Extraction
23. Bank-Fees Extraction
24. Loyalty-Surveillance-Pricing Extraction
25. Managed-Philanthropy Extraction
26. Litigation-Loop Extraction
27. Autonomous-Lethality Extraction
28. Predictive-Policing Extraction
29. Immigration-Automation Extraction
30. Pension-Fees Extraction

---

© 2026 L.M. Marlowe. All rights reserved. Full audits and findings: https://marloweaudit.com/.
